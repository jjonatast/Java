import java.util.ArrayList;

public class Comida extends Produto {
    private ArrayList<Produto> listaDeProdutos;
    private void novaQuantidade(int quantidade) {
    }
    public Comida(String nome, int quantidade, double valor, int codigo) {
        super(nome, quantidade, valor, codigo);
        listaDeProdutos = new ArrayList<>();
    }

    @Override
    public void mostrarDetalhes() {
       super.mostrarDetalhes();
    }

    public void adicionarProduto(Produto produto) {
        listaDeProdutos.add(produto);
    }

    public void atualizarQuantidade(int codigo, int quantidadeASomar) {
        for (Produto produto : listaDeProdutos) {
            if (produto.getCodigo() == codigo) {
                int quantidadeAtual = produto.getQuantidade();
                produto.setQuantidade(quantidadeAtual + quantidadeASomar);
                break;
            }
        }
    }





    public void estoqueComida() {
//
        System.out.println("\nTipo: Comida");
//
        for (Produto produto : listaDeProdutos) {
            produto.mostrarDetalhes();
        }
        System.out.println(listaDeProdutos);
    }
   }






