import java.util.ArrayList;

public class Eletronico extends Produto {
    private ArrayList<Produto> listaDeProdutos;

    public Eletronico(String nome, int quantidade, double valor, int codigo) {
        super(nome, quantidade, valor, codigo);
        listaDeProdutos = new ArrayList<>();
    }

    @Override
    public void mostrarDetalhes() {
       super.mostrarDetalhes();

    }

    public void adicionarProduto(Produto produto) {
        listaDeProdutos.add(produto);
    }

    public void estoqueDeEletronicos() {
        System.out.println("Tipo: Eletrônico");

        for (Produto produto : listaDeProdutos) {
            produto.mostrarDetalhes();
        }
        System.out.println(listaDeProdutos);
    }
    public void atualizarEletronico(int codigo, int novaQuantidade) {

        for (Produto produto:listaDeProdutos){
            if (produto.getCodigo()==codigo){
                produto.setQuantidade(novaQuantidade);

                break;
            }
        }
    }
}

