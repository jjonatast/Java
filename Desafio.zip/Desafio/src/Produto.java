
public abstract class Produto {

    private String nome;
    private int quantidade;
    private double valor;
    private int codigo;

    public Produto(String nome, int quantidade, double valor, int codigo) {

        this.nome = nome;
        this.quantidade = quantidade;
        this.valor = valor;
        this.codigo = codigo;

    }

    public void mostrarDetalhes() {
    }

    @Override
    public String toString() {
        return "\nNome: " + nome + ", Quant.: " + quantidade + ", Preço: R$ " + valor + ", Código: " + codigo;
    }


    public Produto (String nome){
        this.setNome(nome);
   }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int novaQuantidade) { this.quantidade = quantidade;}

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }


      public String dados() {

        System.out.println("Nome: " + getNome() + "\nCódigo: " + getCodigo());
        System.out.println("Qntidade: " + getQuantidade() + "\nValor: " + getValor());
          return null;
      }


}

