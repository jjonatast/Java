import java.util.ArrayList;

public class Roupa extends Produto {
      private ArrayList<Produto> listaDeProdutos;

    public Roupa(String nome, int quantidade, double valor, int codigo) {
        super(nome, quantidade, valor, codigo);
        listaDeProdutos = new ArrayList<>();
    }

    @Override
    public void mostrarDetalhes() {
       super.mostrarDetalhes();
    }

    public void adicionarProduto(Produto produto) {
        listaDeProdutos.add(produto);
    }
    public void estoqueDeRoupa() {

        System.out.println("\nTipo: Roupa");
        for (Produto produto : listaDeProdutos) {
            produto.mostrarDetalhes();
        }
        System.out.println(listaDeProdutos + "\n");
    }

    public void atualizarRoupa(int codigo, int novaQuantidade, double novoValor) {

  for (Produto produto:listaDeProdutos){
      if (produto.getCodigo()==codigo){
          produto.setQuantidade(novaQuantidade);
          produto.setValor(novoValor);
          break;
      }
  }
    }
}

