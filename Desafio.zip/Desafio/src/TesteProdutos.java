

import java.util.ArrayList;

public class TesteProdutos {

    public static void main(String[] args) {


        Produto fone = new Eletronico("EDX", 50, 90, 2525);
        Produto camiseta = new Roupa("CAMISETA", 100, 80, 3535);
        Produto tenis = new Roupa("NIKE", 3, 20, 3434);
        Produto comida = new Comida("PÃO", 10, 2, 5555);
        Produto fruta = new Comida("MAÇÃ", 500, 2.5, 5500);
        Produto proteina = new Comida("OVO", 30, 3, 4441);

        ((Comida) comida).adicionarProduto(comida);
        ((Comida) comida).adicionarProduto(fruta);
        ((Comida) comida).adicionarProduto(proteina);
        ((Roupa) camiseta).adicionarProduto(camiseta);
        ((Roupa) camiseta).adicionarProduto(tenis);
        ((Eletronico)fone).adicionarProduto(fone);


        ((Comida)comida).atualizarQuantidade(5555,500);



      ((Comida) comida).estoqueComida();
        ((Eletronico)fone).estoqueDeEletronicos();






    }
}



